"""
═══════════════════════════════════════════════════════════════════════════════
🚦 SIGNAL ROUTER — validate signal trước khi đẩy vào DB
═══════════════════════════════════════════════════════════════════════════════
- Nạp config.json để biết các bot_id hợp lệ.
- Server gọi router.validate(signal) trước khi log vào DB.
- Worker tự đọc config.json để biết MT5 account của từng bot_id.
"""
import json
import logging
from pathlib import Path

logger = logging.getLogger("Router")

CONFIG_PATH = Path(__file__).parent / "config.json"


def load_config() -> dict:
    """Đọc config.json. Reload mỗi lần gọi để chỉnh JSON không cần restart."""
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        logger.error(f"❌ Không tìm thấy {CONFIG_PATH}")
        return {"bots": {}}
    except json.JSONDecodeError as e:
        logger.error(f"❌ config.json lỗi cú pháp JSON: {e}")
        return {"bots": {}}


class SignalRouter:
    VALID_ACTIONS = {"BUY", "SELL", "CLOSE"}

    def __init__(self):
        cfg = load_config()
        self.bots = cfg.get("bots", {})
        logger.info(f"✓ Router loaded {len(self.bots)} bot(s): {list(self.bots.keys())}")

    def validate(self, signal) -> tuple[bool, str]:
        """
        Kiểm tra signal hợp lệ chưa.
        Trả về (ok, reason). Nếu không ok, reason là lý do để log skipped.
        """
        # 1) bot_id phải nằm trong config
        if signal.bot_id not in self.bots:
            return False, f"bot_id '{signal.bot_id}' chưa có trong config.json"

        # 2) action phải hợp lệ
        action = (signal.action or "").upper()
        if action not in self.VALID_ACTIONS:
            return False, f"action '{signal.action}' không hợp lệ (chỉ BUY/SELL/CLOSE)"

        # 3) BUY/SELL phải có giá (để worker validate SL/TP)
        if action in {"BUY", "SELL"} and signal.price is None:
            return False, "thiếu price (cần để validate SL/TP)"

        # 4) Nếu config bắt require_sl mà webhook không gửi sl
        #    và bot không có fallback_sl_distance → reject sớm
        bot_cfg = self.bots[signal.bot_id]
        if action in {"BUY", "SELL"} and bot_cfg.get("require_sl", True):
            has_sl = signal.sl is not None
            has_fallback = bot_cfg.get("fallback_sl_distance", 0) > 0
            if not has_sl and not has_fallback:
                return False, "require_sl=true nhưng không có sl webhook và không có fallback"

        return True, "ok"

    def reload(self):
        """Cho phép reload không cần restart server (tiện thêm bot mới)."""
        cfg = load_config()
        self.bots = cfg.get("bots", {})
        logger.info(f"🔄 Router reloaded: {len(self.bots)} bot(s)")
