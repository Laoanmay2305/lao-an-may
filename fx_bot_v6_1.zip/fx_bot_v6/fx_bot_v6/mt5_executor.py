"""
═══════════════════════════════════════════════════════════════════════════════
🔌 MT5 EXECUTOR — kết nối MetaTrader 5 và thực thi lệnh
═══════════════════════════════════════════════════════════════════════════════
Mỗi instance = 1 tài khoản MT5.
Worker sẽ tạo nhiều instance, mỗi instance cho 1 bot_id.
"""
import logging
from datetime import datetime, time as dtime
from typing import Optional

import MetaTrader5 as mt5

logger = logging.getLogger("MT5Executor")


class MT5Executor:
    def __init__(
        self,
        login: int,
        password: str,
        server: str,
        symbol: str = "XAUUSD",
        magic: int = 1000,
        path: Optional[str] = None,
        bot_name: str = "BOT",
    ):
        self.login = login
        self.password = password
        self.server = server
        self.symbol = symbol
        self.magic = magic
        self.path = path
        self.bot_name = bot_name
        self.connected = False

    # ─────────────────────────────────────────────────────────────────────
    # Kết nối
    # ─────────────────────────────────────────────────────────────────────
    def connect(self) -> bool:
        try:
            init_kwargs = {
                "login": self.login,
                "password": self.password,
                "server": self.server,
            }
            if self.path:
                init_kwargs["path"] = self.path

            if not mt5.initialize(**init_kwargs):
                logger.error(f"[{self.bot_name}] ❌ MT5 init failed: {mt5.last_error()}")
                return False

            symbol_info = mt5.symbol_info(self.symbol)
            if symbol_info is None:
                logger.error(f"[{self.bot_name}] ❌ Symbol {self.symbol} not found")
                return False
            if not symbol_info.visible:
                if not mt5.symbol_select(self.symbol, True):
                    logger.error(f"[{self.bot_name}] ❌ Cannot enable {self.symbol}")
                    return False

            self.connected = True
            logger.info(f"[{self.bot_name}] ✓ MT5 connected: {self.login}@{self.server}")
            return True
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Connect error: {e}")
            return False

    def disconnect(self):
        try:
            mt5.shutdown()
            self.connected = False
            logger.info(f"[{self.bot_name}] ✓ MT5 disconnected")
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Disconnect error: {e}")

    # ─────────────────────────────────────────────────────────────────────
    # P&L hôm nay (single source of truth)
    # ─────────────────────────────────────────────────────────────────────
    def get_today_total_pnl(self) -> float:
        """
        Trả về tổng P&L hôm nay (USD):
          - profit + commission + swap của các deal đã đóng từ 00:00
          - cộng floating P&L của các position đang mở
        CHỈ tính các lệnh thuộc magic number của bot này.
        """
        if not self.connected:
            return 0.0

        total = 0.0
        try:
            start_of_day = datetime.combine(datetime.now().date(), dtime.min)
            now = datetime.now()
            deals = mt5.history_deals_get(start_of_day, now)
            if deals:
                for d in deals:
                    if d.symbol != self.symbol:
                        continue
                    if d.magic != self.magic:
                        continue

                    total += d.profit

            positions = mt5.positions_get(symbol=self.symbol)
            if positions:
                for p in positions:
                    if p.magic != self.magic:
                        continue
                    total += p.profit
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Cannot read P&L: {e}")
            return 0.0

        return round(total, 2)

    # ─────────────────────────────────────────────────────────────────────
    # Đếm lệnh đang mở
    # ─────────────────────────────────────────────────────────────────────
    def count_open_orders(self) -> int:
        if not self.connected:
            return 0
        try:
            positions = mt5.positions_get(symbol=self.symbol)
            if not positions:
                return 0
            return sum(1 for p in positions if p.magic == self.magic)
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Cannot count orders: {e}")
            return 0

    # ─────────────────────────────────────────────────────────────────────
    # Gửi lệnh market
    # ─────────────────────────────────────────────────────────────────────
    def send_order(
        self,
        direction: str,  # "BUY" hoặc "SELL"
        lot: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        sl_distance: float = 0.0,  # fallback nếu sl=None: tính SL = giá_MT5 ± sl_distance
        tp_distance: float = 0.0,  # fallback nếu tp=None: tính TP = giá_MT5 ± tp_distance
        comment: str = "",
    ) -> Optional[int]:
        if not self.connected:
            logger.error(f"[{self.bot_name}] ❌ Not connected")
            return None

        if direction == "BUY":
            order_type = mt5.ORDER_TYPE_BUY
        elif direction == "SELL":
            order_type = mt5.ORDER_TYPE_SELL
        else:
            logger.error(f"[{self.bot_name}] ❌ Invalid direction: {direction}")
            return None

        try:
            tick = mt5.symbol_info_tick(self.symbol)
            if tick is None:
                logger.error(f"[{self.bot_name}] ❌ No tick for {self.symbol}")
                return None
            price = tick.ask if direction == "BUY" else tick.bid

            request = {
                "action": mt5.TRADE_ACTION_DEAL,
                "symbol": self.symbol,
                "volume": float(lot),
                "type": order_type,
                "price": price,
                "deviation": 20,
                "magic": self.magic,
                "comment": comment[:31] if comment else self.bot_name,
                "type_time": mt5.ORDER_TIME_GTC,
                "type_filling": mt5.ORDER_FILLING_IOC,
            }

            # ── Tính SL/TP dựa trên GIÁ MT5 THẬT (price ở trên = tick.ask/bid) ──
            symbol_info = mt5.symbol_info(self.symbol)
            digits = symbol_info.digits if symbol_info else 3
            point = symbol_info.point if symbol_info else 0.01
            min_stop_points = symbol_info.trade_stops_level if symbol_info else 0
            broker_min_distance = min_stop_points * point

            # Safety buffer: dù broker cho phép = 0 thì ta cũng cần khoảng cách tối thiểu thực tế
            # để tránh SL/TP bị quét ngay khi vừa vào lệnh do spread/slippage.
            SAFETY_BUFFER = 0.5  # đơn vị giá (vd: 50 cent XAUUSD)
            min_stop_distance = max(broker_min_distance, SAFETY_BUFFER)

            # ═══════════════════════════════════════════════════════════════════
            # CHUYỂN ĐỔI: sl_distance / tp_distance ĐƯỢC HIỂU LÀ USD (số tiền lỗ/lãi)
            # ═══════════════════════════════════════════════════════════════════
            # Cách MT5 tính lãi/lỗ XAUUSD:
            #   profit_usd = (price_change) × lot × contract_size
            #   Với XAUUSD: contract_size = 100 (1 lot = 100 oz)
            #   → profit_usd = price_change × lot × 100
            #
            # Nghịch đảo để tính khoảng cách giá khi biết USD muốn lỗ:
            #   price_change = target_usd / (lot × contract_size)
            #
            # Dùng mt5.order_calc_profit() để CHÍNH XÁC TUYỆT ĐỐI với broker này
            # (tự xử lý contract_size, point, currency conversion nếu cần).

            def usd_to_price_distance(target_usd: float) -> float:
                """
                Chuyển USD lỗ/lãi mong muốn → khoảng cách giá.
                Dùng mt5.order_calc_profit để query chính xác từ broker.
                """
                if target_usd <= 0:
                    return 0.0
                # Test với khoảng cách 10 đơn vị giá để query
                test_distance = 10.0
                test_close_buy = price - test_distance  # giả định BUY lỗ
                profit_at_test = mt5.order_calc_profit(
                    mt5.ORDER_TYPE_BUY,
                    self.symbol,
                    lot,
                    price,
                    test_close_buy
                )
                if profit_at_test is None or profit_at_test == 0:
                    # Fallback: dùng công thức thủ công cho XAUUSD
                    contract_size = symbol_info.trade_contract_size if symbol_info else 100
                    return target_usd / (lot * contract_size)
                # |profit_at_test| USD ứng với test_distance đơn vị giá
                # → mỗi 1 USD lỗ = test_distance / |profit_at_test| đơn vị giá
                return target_usd * test_distance / abs(profit_at_test)

            # Tính khoảng cách giá tương ứng với SL_USD và TP_USD
            sl_price_distance = usd_to_price_distance(sl_distance) if sl_distance > 0 else 0
            tp_price_distance = usd_to_price_distance(tp_distance) if tp_distance > 0 else 0

            if sl_price_distance > 0:
                logger.info(
                    f"[{self.bot_name}] SL=${sl_distance} USD → cách giá {sl_price_distance:.{digits}f} đơn vị "
                    f"(lot={lot})"
                )
            if tp_price_distance > 0:
                logger.info(
                    f"[{self.bot_name}] TP=${tp_distance} USD → cách giá {tp_price_distance:.{digits}f} đơn vị "
                    f"(lot={lot})"
                )

            # ─── SL ───
            # Nếu webhook không gửi sl → tự tính từ giá MT5 thật với khoảng cách USD đã quy đổi
            if sl is None and sl_price_distance > 0:
                sl = (price - sl_price_distance if direction == "BUY" else price + sl_price_distance)
                logger.info(f"[{self.bot_name}] SL auto-tính từ giá MT5: {sl:.{digits}f}")

            if sl is not None:
                request["sl"] = float(f"{sl:.3f}")
                # Validate hướng + khoảng cách
                if direction == "BUY":
                    distance = price - sl
                    if distance < min_stop_distance:
                        logger.warning(
                            f"[{self.bot_name}] ⚠ SL không hợp lệ "
                            f"(cách {distance:.{digits}f}, cần >= {min_stop_distance:.{digits}f}). "
                            f"Tự đặt SL = giá - {min_stop_distance}"
                        )
                        sl = round(price - min_stop_distance, digits)
                else:  # SELL
                    distance = sl - price
                    if distance < min_stop_distance:
                        logger.warning(
                            f"[{self.bot_name}] ⚠ SL không hợp lệ "
                            f"(cách {distance:.{digits}f}, cần >= {min_stop_distance:.{digits}f}). "
                            f"Tự đặt SL = giá + {min_stop_distance}"
                        )
                        sl = round(price + min_stop_distance, digits)
                request["sl"] = sl

            # ─── TP ───
            if tp is None and tp_price_distance > 0:
                tp = (price + tp_price_distance if direction == "BUY" else price - tp_price_distance)
                logger.info(f"[{self.bot_name}] TP auto-tính từ giá MT5: {tp:.{digits}f}")

            if tp is not None:
                request["tp"] = float(f"{tp:.3f}")
                if direction == "BUY":
                    distance = tp - price
                    if distance < min_stop_distance:
                        logger.warning(
                            f"[{self.bot_name}] ⚠ TP không hợp lệ. "
                            f"Tự đặt TP = giá + {min_stop_distance}"
                        )
                        tp = round(price + min_stop_distance, digits)
                else:  # SELL
                    distance = price - tp
                    if distance < min_stop_distance:
                        logger.warning(
                            f"[{self.bot_name}] ⚠ TP không hợp lệ. "
                            f"Tự đặt TP = giá - {min_stop_distance}"
                        )
                        tp = round(price - min_stop_distance, digits)
                request["tp"] = tp

            result = mt5.order_send(request)
            if result.retcode != mt5.TRADE_RETCODE_DONE:
                logger.error(
                    f"[{self.bot_name}] ❌ Order failed: retcode={result.retcode} "
                    f"comment={result.comment}"
                )
                return None

            logger.info(
                f"[{self.bot_name}] ✅ Order #{result.order} {direction} {lot}lot "
                f"@{price:.3f} SL={sl} TP={tp}"
            )
            return result.order
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Send order exception: {e}")
            return None

    # ─────────────────────────────────────────────────────────────────────
    # Đóng tất cả lệnh đang mở của bot này
    # ─────────────────────────────────────────────────────────────────────
    def close_all(self) -> int:
        """Đóng mọi position thuộc magic này. Trả về số lệnh đã đóng."""
        if not self.connected:
            return 0

        closed = 0
        try:
            positions = mt5.positions_get(symbol=self.symbol)
            if not positions:
                return 0

            for pos in positions:
                if pos.magic != self.magic:
                    continue

                tick = mt5.symbol_info_tick(self.symbol)
                if tick is None:
                    continue

                if pos.type == mt5.POSITION_TYPE_BUY:
                    close_type = mt5.ORDER_TYPE_SELL
                    close_price = tick.bid
                else:
                    close_type = mt5.ORDER_TYPE_BUY
                    close_price = tick.ask

                request = {
                    "action": mt5.TRADE_ACTION_DEAL,
                    "symbol": self.symbol,
                    "volume": pos.volume,
                    "type": close_type,
                    "position": pos.ticket,
                    "price": close_price,
                    "deviation": 20,
                    "magic": self.magic,
                    "comment": "CLOSE_BY_WEBHOOK",
                    "type_time": mt5.ORDER_TIME_GTC,
                    "type_filling": mt5.ORDER_FILLING_IOC,
                }
                result = mt5.order_send(request)
                if result.retcode == mt5.TRADE_RETCODE_DONE:
                    closed += 1
                    logger.info(f"[{self.bot_name}] ✓ Closed #{pos.ticket}")
                else:
                    logger.error(
                        f"[{self.bot_name}] ❌ Close failed #{pos.ticket}: {result.retcode}"
                    )
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Close all exception: {e}")

        return closed
