"""
═══════════════════════════════════════════════════════════════════════════════
🔌 MT5 EXECUTOR — kết nối MetaTrader 5 và thực thi lệnh
═══════════════════════════════════════════════════════════════════════════════
Mỗi instance = 1 tài khoản MT5.
Worker sẽ tạo nhiều instance, mỗi instance cho 1 bot_id.
"""
import logging
from datetime import datetime, time as dtime
from typing import Optional

import MetaTrader5 as mt5

logger = logging.getLogger("MT5Executor")


class MT5Executor:
    def __init__(
        self,
        login: int,
        password: str,
        server: str,
        symbol: str = "XAUUSD",
        magic: int = 1000,
        path: Optional[str] = None,
        bot_name: str = "BOT",
    ):
        self.login = login
        self.password = password
        self.server = server
        self.symbol = symbol
        self.magic = magic
        self.path = path
        self.bot_name = bot_name
        self.connected = False

    # ─────────────────────────────────────────────────────────────────────
    # Kết nối
    # ─────────────────────────────────────────────────────────────────────
    def connect(self) -> bool:
        try:
            init_kwargs = {
                "login": self.login,
                "password": self.password,
                "server": self.server,
            }
            if self.path:
                init_kwargs["path"] = self.path

            if not mt5.initialize(**init_kwargs):
                logger.error(f"[{self.bot_name}] ❌ MT5 init failed: {mt5.last_error()}")
                return False

            symbol_info = mt5.symbol_info(self.symbol)
            if symbol_info is None:
                logger.error(f"[{self.bot_name}] ❌ Symbol {self.symbol} not found")
                return False
            if not symbol_info.visible:
                if not mt5.symbol_select(self.symbol, True):
                    logger.error(f"[{self.bot_name}] ❌ Cannot enable {self.symbol}")
                    return False

            self.connected = True
            logger.info(f"[{self.bot_name}] ✓ MT5 connected: {self.login}@{self.server}")
            return True
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Connect error: {e}")
            return False

    def disconnect(self):
        try:
            mt5.shutdown()
            self.connected = False
            logger.info(f"[{self.bot_name}] ✓ MT5 disconnected")
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Disconnect error: {e}")

    # ─────────────────────────────────────────────────────────────────────
    # P&L hôm nay (single source of truth)
    # ─────────────────────────────────────────────────────────────────────
    def get_today_total_pnl(self) -> float:
        """
        Trả về tổng P&L hôm nay (USD):
          - profit + commission + swap của các deal đã đóng từ 00:00
          - cộng floating P&L của các position đang mở
        CHỈ tính các lệnh thuộc magic number của bot này.
        """
        if not self.connected:
            return 0.0

        total = 0.0
        try:
            start_of_day = datetime.combine(datetime.now().date(), dtime.min)
            now = datetime.now()
            deals = mt5.history_deals_get(start_of_day, now)
            if deals:
                for d in deals:
                    if d.symbol != self.symbol:
                        continue
                    if d.magic != self.magic:
                        continue

                    total += d.profit

            positions = mt5.positions_get(symbol=self.symbol)
            if positions:
                for p in positions:
                    if p.magic != self.magic:
                        continue
                    total += p.profit
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Cannot read P&L: {e}")
            return 0.0

        return round(total, 2)

    # ─────────────────────────────────────────────────────────────────────
    # Đếm lệnh đang mở
    # ─────────────────────────────────────────────────────────────────────
    def count_open_orders(self) -> int:
        if not self.connected:
            return 0
        try:
            positions = mt5.positions_get(symbol=self.symbol)
            if not positions:
                return 0
            return sum(1 for p in positions if p.magic == self.magic)
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Cannot count orders: {e}")
            return 0

    # ─────────────────────────────────────────────────────────────────────
    # Gửi lệnh market
    # ─────────────────────────────────────────────────────────────────────
    def send_order(
        self,
        direction: str,  # "BUY" hoặc "SELL"
        lot: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: str = "",
    ) -> Optional[int]:
        if not self.connected:
            logger.error(f"[{self.bot_name}] ❌ Not connected")
            return None

        if direction == "BUY":
            order_type = mt5.ORDER_TYPE_BUY
        elif direction == "SELL":
            order_type = mt5.ORDER_TYPE_SELL
        else:
            logger.error(f"[{self.bot_name}] ❌ Invalid direction: {direction}")
            return None

        try:
            tick = mt5.symbol_info_tick(self.symbol)
            if tick is None:
                logger.error(f"[{self.bot_name}] ❌ No tick for {self.symbol}")
                return None
            price = tick.ask if direction == "BUY" else tick.bid

            request = {
                "action": mt5.TRADE_ACTION_DEAL,
                "symbol": self.symbol,
                "volume": float(lot),
                "type": order_type,
                "price": price,
                "deviation": 20,
                "magic": self.magic,
                "comment": comment[:31] if comment else self.bot_name,
                "type_time": mt5.ORDER_TIME_GTC,
                "type_filling": mt5.ORDER_FILLING_IOC,
            }

            # ── Gắn SL/TP vào request, có normalize theo digits của symbol ──
            symbol_info = mt5.symbol_info(self.symbol)
            digits = symbol_info.digits if symbol_info else 3
            point = symbol_info.point if symbol_info else 0.01
            min_stop_points = symbol_info.trade_stops_level if symbol_info else 0
            min_stop_distance = min_stop_points * point  # khoảng cách tối thiểu (theo giá)

            if sl is not None:
                sl = round(float(sl), digits)
                # Kiểm tra SL có cách giá hiện tại đủ xa không
                if direction == "BUY" and (price - sl) < min_stop_distance:
                    logger.warning(
                        f"[{self.bot_name}] ⚠ SL quá gần giá "
                        f"(cách {price - sl:.{digits}f}, broker yêu cầu >= {min_stop_distance:.{digits}f}). "
                        f"Đẩy SL ra xa hơn."
                    )
                    sl = round(price - min_stop_distance * 1.1, digits)
                elif direction == "SELL" and (sl - price) < min_stop_distance:
                    logger.warning(
                        f"[{self.bot_name}] ⚠ SL quá gần giá "
                        f"(cách {sl - price:.{digits}f}, broker yêu cầu >= {min_stop_distance:.{digits}f}). "
                        f"Đẩy SL ra xa hơn."
                    )
                    sl = round(price + min_stop_distance * 1.1, digits)
                request["sl"] = sl

            if tp is not None:
                tp = round(float(tp), digits)
                if direction == "BUY" and (tp - price) < min_stop_distance:
                    logger.warning(
                        f"[{self.bot_name}] ⚠ TP quá gần giá. Đẩy TP ra xa hơn."
                    )
                    tp = round(price + min_stop_distance * 1.1, digits)
                elif direction == "SELL" and (price - tp) < min_stop_distance:
                    logger.warning(
                        f"[{self.bot_name}] ⚠ TP quá gần giá. Đẩy TP ra xa hơn."
                    )
                    tp = round(price - min_stop_distance * 1.1, digits)
                request["tp"] = tp

            result = mt5.order_send(request)
            if result.retcode != mt5.TRADE_RETCODE_DONE:
                logger.error(
                    f"[{self.bot_name}] ❌ Order failed: retcode={result.retcode} "
                    f"comment={result.comment}"
                )
                return None

            logger.info(
                f"[{self.bot_name}] ✅ Order #{result.order} {direction} {lot}lot "
                f"@{price:.3f} SL={sl} TP={tp}"
            )
            return result.order
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Send order exception: {e}")
            return None

    # ─────────────────────────────────────────────────────────────────────
    # Đóng tất cả lệnh đang mở của bot này
    # ─────────────────────────────────────────────────────────────────────
    def close_all(self) -> int:
        """Đóng mọi position thuộc magic này. Trả về số lệnh đã đóng."""
        if not self.connected:
            return 0

        closed = 0
        try:
            positions = mt5.positions_get(symbol=self.symbol)
            if not positions:
                return 0

            for pos in positions:
                if pos.magic != self.magic:
                    continue

                tick = mt5.symbol_info_tick(self.symbol)
                if tick is None:
                    continue

                if pos.type == mt5.POSITION_TYPE_BUY:
                    close_type = mt5.ORDER_TYPE_SELL
                    close_price = tick.bid
                else:
                    close_type = mt5.ORDER_TYPE_BUY
                    close_price = tick.ask

                request = {
                    "action": mt5.TRADE_ACTION_DEAL,
                    "symbol": self.symbol,
                    "volume": pos.volume,
                    "type": close_type,
                    "position": pos.ticket,
                    "price": close_price,
                    "deviation": 20,
                    "magic": self.magic,
                    "comment": "CLOSE_BY_WEBHOOK",
                    "type_time": mt5.ORDER_TIME_GTC,
                    "type_filling": mt5.ORDER_FILLING_IOC,
                }
                result = mt5.order_send(request)
                if result.retcode == mt5.TRADE_RETCODE_DONE:
                    closed += 1
                    logger.info(f"[{self.bot_name}] ✓ Closed #{pos.ticket}")
                else:
                    logger.error(
                        f"[{self.bot_name}] ❌ Close failed #{pos.ticket}: {result.retcode}"
                    )
        except Exception as e:
            logger.error(f"[{self.bot_name}] ❌ Close all exception: {e}")

        return closed
