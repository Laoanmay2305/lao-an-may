"""
═══════════════════════════════════════════════════════════════════════════════
🌐 WEBHOOK SERVER — nhận tín hiệu từ TradingView
═══════════════════════════════════════════════════════════════════════════════
Flow:
  TradingView → Cloudflare Tunnel → FastAPI/webhook → validate → log DB (pending)
  Worker process đọc DB → đẩy lệnh vào MT5

CHẠY:
  python server.py
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import uvicorn
import logging

from database import SignalDB
from router import SignalRouter

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("WebhookServer")

app = FastAPI(title="FX Bot Webhook Server v6")

db = SignalDB()
router = SignalRouter()


class TradingSignal(BaseModel):
    bot_id: str
    action: str  # BUY / SELL / CLOSE
    price: Optional[float] = None
    sl: Optional[float] = None
    tp: Optional[float] = None


@app.post("/webhook")
async def receive_webhook(signal: TradingSignal):
    logger.info(
        f"🟢 SIGNAL: {signal.bot_id} {signal.action} "
        f"price={signal.price} sl={signal.sl} tp={signal.tp}"
    )

    payload = signal.model_dump()

    # Validate trước khi log
    ok, reason = router.validate(signal)

    if not ok:
        # Vẫn log để bạn xem lịch sử, nhưng status='skipped' để worker bỏ qua
        row_id = db.log_signal(payload, source="webhook")
        if row_id:
            db.update_status(row_id, status="skipped", note=reason)
        logger.warning(f"⏭ Skipped: {reason}")
        raise HTTPException(status_code=400, detail=reason)

    # OK → log với status='pending', worker sẽ xử lý
    row_id = db.log_signal(payload, source="webhook")
    return {
        "status": "queued",
        "signal_id": row_id,
        "message": f"Queued for {signal.bot_id}",
    }


@app.post("/reload")
async def reload_config():
    """Reload config.json không cần restart server."""
    router.reload()
    return {"status": "ok", "bots": list(router.bots.keys())}


@app.get("/health")
async def health_check():
    return {"status": "ok", "bots": list(router.bots.keys())}


@app.get("/signals/recent")
async def recent_signals(limit: int = 20):
    """Xem 20 signal gần nhất (debug)."""
    import sqlite3

    conn = sqlite3.connect(db.db_path)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(
        """
        SELECT id, timestamp, bot_id, action, price, status, result_note, mt5_ticket
        FROM incoming_signals
        ORDER BY id DESC
        LIMIT ?
        """,
        (limit,),
    )
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


if __name__ == "__main__":
    logger.info("=" * 70)
    logger.info("Khởi động Webhook Server tại http://0.0.0.0:8000")
    logger.info("Endpoints:")
    logger.info("  POST /webhook         — TradingView bắn vào đây")
    logger.info("  GET  /health          — kiểm tra server")
    logger.info("  GET  /signals/recent  — xem 20 signal gần nhất")
    logger.info("  POST /reload          — reload config.json")
    logger.info("=" * 70)
    uvicorn.run(app, host="0.0.0.0", port=8000)
