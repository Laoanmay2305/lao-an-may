"""
═══════════════════════════════════════════════════════════════════════════════
🗄️ SQLite Database — lưu mọi signal nhận được + trạng thái xử lý
═══════════════════════════════════════════════════════════════════════════════
Server ghi signal vào với status='pending'.
Worker đọc các signal status='pending' → thực thi → cập nhật status.

Status:
  pending   — vừa nhận, chờ xử lý
  done      — đã gửi MT5 thành công
  skipped   — bị từ chối (daily limit, no SL, max orders, bot_id sai, ...)
  failed    — gửi MT5 nhưng lỗi
"""
import sqlite3
import json
import logging
from datetime import datetime
from typing import Optional

logger = logging.getLogger("Database")


class SignalDB:
    def __init__(self, db_path: str = "signals.db"):
        self.db_path = db_path
        self._create_table()

    def _create_table(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS incoming_signals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                bot_id TEXT,
                action TEXT,
                price REAL,
                sl REAL,
                tp REAL,
                raw_payload TEXT,
                source TEXT,
                status TEXT DEFAULT 'pending',
                result_note TEXT,
                mt5_ticket INTEGER,
                processed_at DATETIME
            )
            """
        )
        # Migrate cho DB cũ (không có 4 cột mới)
        for col, ddl in [
            ("status", "ALTER TABLE incoming_signals ADD COLUMN status TEXT DEFAULT 'pending'"),
            ("result_note", "ALTER TABLE incoming_signals ADD COLUMN result_note TEXT"),
            ("mt5_ticket", "ALTER TABLE incoming_signals ADD COLUMN mt5_ticket INTEGER"),
            ("processed_at", "ALTER TABLE incoming_signals ADD COLUMN processed_at DATETIME"),
        ]:
            try:
                cursor.execute(ddl)
            except sqlite3.OperationalError:
                pass  # cột đã tồn tại

        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_status ON incoming_signals(status, timestamp)"
        )
        conn.commit()
        conn.close()
        logger.info("✓ SQLite ready (table: incoming_signals)")

    # ─────────────────────────────────────────────────────────────────────
    # Server gọi
    # ─────────────────────────────────────────────────────────────────────
    def log_signal(self, signal_dict: dict, source: str = "webhook") -> Optional[int]:
        """Ghi signal mới với status='pending'. Trả về row id."""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                """
                INSERT INTO incoming_signals
                    (bot_id, action, price, sl, tp, raw_payload, source, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
                """,
                (
                    signal_dict.get("bot_id"),
                    signal_dict.get("action"),
                    signal_dict.get("price"),
                    signal_dict.get("sl"),
                    signal_dict.get("tp"),
                    json.dumps(signal_dict),
                    source,
                ),
            )
            row_id = cursor.lastrowid
            conn.commit()
            conn.close()
            return row_id
        except Exception as e:
            logger.error(f"❌ log_signal error: {e}")
            return None

    # ─────────────────────────────────────────────────────────────────────
    # Worker gọi
    # ─────────────────────────────────────────────────────────────────────
    def fetch_pending(self, limit: int = 20) -> list:
        """Lấy các signal đang pending (cũ nhất trước)."""
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT id, bot_id, action, price, sl, tp, raw_payload, timestamp
                FROM incoming_signals
                WHERE status = 'pending'
                ORDER BY id ASC
                LIMIT ?
                """,
                (limit,),
            )
            rows = [dict(r) for r in cursor.fetchall()]
            conn.close()
            return rows
        except Exception as e:
            logger.error(f"❌ fetch_pending error: {e}")
            return []

    def update_status(
        self,
        signal_id: int,
        status: str,
        note: str = "",
        mt5_ticket: Optional[int] = None,
    ):
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute(
                """
                UPDATE incoming_signals
                SET status = ?, result_note = ?, mt5_ticket = ?, processed_at = ?
                WHERE id = ?
                """,
                (status, note, mt5_ticket, datetime.now().isoformat(timespec="seconds"), signal_id),
            )
            conn.commit()
            conn.close()
        except Exception as e:
            logger.error(f"❌ update_status error: {e}")
