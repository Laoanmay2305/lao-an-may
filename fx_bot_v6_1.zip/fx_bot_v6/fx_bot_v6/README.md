# FX Bot v6 — TradingView → MT5

Hệ thống nhận webhook từ TradingView và tự động đẩy lệnh vào MetaTrader 5.

## Kiến trúc

```
TradingView Alert
       ↓ (JSON webhook)
Cloudflare Tunnel
       ↓
[server.py] FastAPI :8000
   - validate signal
   - ghi vào signals.db (status='pending')
       ↓
[worker.py] (process riêng, chạy ngầm)
   - đọc DB mỗi 1s
   - lazy-connect MT5 cho từng bot_id
   - kiểm tra Daily TP/SL, Max orders, SL/TP
   - gửi lệnh MT5 → update status
       ↓
MetaTrader 5 (1 hoặc nhiều account)
```

## File trong project

| File | Vai trò |
|------|---------|
| `config.json` | Map bot_id → MT5 account + lot + risk rules |
| `server.py` | Webhook server FastAPI, nhận từ TradingView |
| `worker.py` | Process xử lý lệnh, đẩy MT5 |
| `database.py` | SQLite layer (table `incoming_signals`) |
| `router.py` | Validate bot_id và action |
| `mt5_executor.py` | Module gửi lệnh MT5, tính P&L ngày |
| `signals.db` | DB tự tạo |

## Cài đặt

### 1. Python packages
```bash
pip install fastapi uvicorn pydantic MetaTrader5
```

### 2. Cấu hình `config.json`
Mở `config.json`, sửa từng bot:
- `mt5_login`, `mt5_password`, `mt5_server` — tài khoản MT5 của bot đó
- `mt5_path` — đường dẫn `terminal64.exe` (nếu có nhiều MT5)
- `magic` — số khác nhau cho từng bot (1001, 1002, 1003 …)
- `lot` — kích cỡ lệnh
- `daily_tp_usd` / `daily_sl_usd` — ngưỡng dừng bot trong ngày
- `fallback_sl_distance` / `fallback_tp_distance` — nếu webhook không gửi sl/tp

⚠ Tên `bot_id` (ví dụ `SHARK_01`) phải khớp **chính xác** với JSON bạn cấu hình trên TradingView Alert.

### 3. Chạy 2 process (mở 2 terminal)

**Terminal 1 — Server:**
```bash
python server.py
```
Đợi thấy `Khởi động Webhook Server tại http://0.0.0.0:8000`

**Terminal 2 — Worker:**
```bash
python worker.py
```
Đợi thấy `⚙️  Worker started`

**Terminal 3 — Cloudflare Tunnel:**
```bash
cloudflared tunnel --url http://localhost:8000
```
Copy URL `https://xxx.trycloudflare.com`

### 4. Cấu hình Alert trên TradingView

- **Webhook URL**: `https://xxx.trycloudflare.com/webhook`
- **Message** (JSON):

Lệnh đầy đủ:
```json
{
  "bot_id": "SHARK_01",
  "action": "BUY",
  "price": {{close}},
  "sl": {{plot("SL")}},
  "tp": {{plot("TP")}}
}
```

Lệnh tối thiểu (sẽ dùng fallback SL/TP từ config):
```json
{
  "bot_id": "SHARK_01",
  "action": "BUY",
  "price": {{close}}
}
```

Đóng tất cả lệnh:
```json
{
  "bot_id": "SHARK_01",
  "action": "CLOSE"
}
```

## Theo dõi hoạt động

### Xem 20 signal gần nhất
```
GET http://localhost:8000/signals/recent
```
Mở trình duyệt vào địa chỉ trên hoặc dùng curl.

### Thêm bot mới mà không restart server
1. Chỉnh `config.json`, thêm bot mới
2. Restart `worker.py` (vẫn cần — vì worker giữ MT5 connection)
3. Gọi `POST /reload` cho server cập nhật router (không cần restart server)

### Các status trong DB
- `pending` — vừa nhận, worker chưa xử lý
- `done` — đã gửi MT5 thành công
- `skipped` — bị từ chối (daily limit, no SL, max orders, bot_id sai, …)
- `failed` — gửi MT5 nhưng lỗi

## Lưu ý quan trọng

1. **Mỗi bot_id 1 MT5 account riêng** — không chạy chung 1 account, tránh xung đột magic và daily limit.

2. **Daily TP/SL đọc từ MT5 history** (không tự đếm) — restart worker giữa ngày vẫn an toàn, không reset profit.

3. **Magic number duy nhất** — Worker chỉ tính P&L và đếm lệnh của magic thuộc bot đó, không lẫn với lệnh manual hay bot khác.

4. **`require_sl: true`** — nếu webhook không gửi `sl` và không có `fallback_sl_distance`, lệnh sẽ bị skip. Tránh "naked trade".

5. **Symbol** — broker Exness dùng `XAUUSDm` cho tài khoản cent, hoặc `XAUUSD` cho standard. Kiểm tra MT5 → Market Watch để biết tên đúng.

## Test thử trên Demo trước

1. Đăng nhập MT5 demo, login `433524035` (hoặc tài khoản demo của bạn)
2. Chạy `server.py` và `worker.py`
3. Trên TradingView, tạo Alert test → bắn JSON với `bot_id: "SHARK_01"`, `action: "BUY"`, `price: 2300`
4. Xem worker log có dòng `✅ Order #xxx BUY 0.01lot` không
5. Mở MT5 → tab Trade → có lệnh mới = OK
