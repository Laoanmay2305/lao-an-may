"""
═══════════════════════════════════════════════════════════════════════════════
⚙️ WORKER — xử lý signal pending → đẩy lệnh vào MT5
═══════════════════════════════════════════════════════════════════════════════
Logic:
  1. Mỗi 1 giây, đọc các signal status='pending' trong DB.
  2. Với mỗi signal:
     - Resolve config theo bot_id
     - Lazy-connect MT5 cho bot_id đó (1 connection / bot_id)
     - Áp dụng quy tắc risk:
         * Daily TP / Daily SL từ MT5 history (single source of truth)
         * Max open orders
         * SL/TP lấy từ webhook nếu có, fallback config nếu không
         * require_sl
     - Gửi lệnh → cập nhật status (done/skipped/failed)

CHẠY:
  python worker.py
"""
import json
import logging
import sys
import time
from pathlib import Path
from typing import Dict, Optional

from database import SignalDB
from mt5_executor import MT5Executor
from router import load_config

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("Worker")

POLL_INTERVAL = 1.0  # giây


class Worker:
    def __init__(self):
        self.db = SignalDB()
        self.config = load_config()
        self.symbol = self.config.get("symbol", "XAUUSD")
        self.bots_config = self.config.get("bots", {})
        # Cache 1 MT5Executor / bot_id (lazy init)
        self.executors: Dict[str, MT5Executor] = {}
        self.running = False

    # ─────────────────────────────────────────────────────────────────────
    def _get_executor(self, bot_id: str) -> Optional[MT5Executor]:
        """Lấy executor cho bot_id, tạo mới nếu chưa có."""
        if bot_id in self.executors:
            return self.executors[bot_id]

        bot_cfg = self.bots_config.get(bot_id)
        if not bot_cfg:
            logger.error(f"❌ Không tìm thấy config cho bot_id={bot_id}")
            return None

        executor = MT5Executor(
            login=int(bot_cfg["mt5_login"]),
            password=str(bot_cfg["mt5_password"]),
            server=str(bot_cfg["mt5_server"]),
            symbol=self.symbol,
            magic=int(bot_cfg.get("magic", 1000)),
            path=bot_cfg.get("mt5_path"),
            bot_name=bot_id,
        )
        if not executor.connect():
            return None

        self.executors[bot_id] = executor

        # Log P&L ngày khi kết nối lần đầu
        pnl = executor.get_today_total_pnl()
        logger.info(f"[{bot_id}] Daily P&L hôm nay từ MT5: ${pnl:.2f}")

        return executor

    # ─────────────────────────────────────────────────────────────────────
    def _compute_sl_tp(
        self,
        signal: dict,
        bot_cfg: dict,
    ) -> tuple[Optional[float], Optional[float], str]:
        """
        Quy tắc: webhook ưu tiên, fallback config.
        Trả về (sl_price, tp_price, note).
        """
        action = signal["action"].upper()
        price = float(signal["price"])
        sl_webhook = signal.get("sl")
        tp_webhook = signal.get("tp")

        # SL
        if sl_webhook is not None:
            sl_price = float(sl_webhook)
            sl_source = "webhook"
        else:
            dist = bot_cfg.get("fallback_sl_distance", 0)
            if dist <= 0:
                return None, None, "no_sl"
            sl_price = price - dist if action == "BUY" else price + dist
            sl_source = f"fallback ({dist})"

        # TP
        if tp_webhook is not None:
            tp_price = float(tp_webhook)
            tp_source = "webhook"
        else:
            dist = bot_cfg.get("fallback_tp_distance", 0)
            if dist <= 0:
                tp_price = None
                tp_source = "none"
            else:
                tp_price = price + dist if action == "BUY" else price - dist
                tp_source = f"fallback ({dist})"

        return sl_price, tp_price, f"SL={sl_source}, TP={tp_source}"

    # ─────────────────────────────────────────────────────────────────────
    def _process_signal(self, sig: dict):
        sid = sig["id"]
        bot_id = sig["bot_id"]
        action = (sig["action"] or "").upper()

        bot_cfg = self.bots_config.get(bot_id)
        if not bot_cfg:
            self.db.update_status(sid, "skipped", "bot_id removed from config")
            return

        executor = self._get_executor(bot_id)
        if not executor:
            self.db.update_status(sid, "failed", "MT5 connect failed")
            return

        # ─── CLOSE ───
        if action == "CLOSE":
            n = executor.close_all()
            self.db.update_status(sid, "done", f"closed {n} position(s)")
            return

        # ─── BUY / SELL ───
        # 1. Daily limits
        pnl = executor.get_today_total_pnl()
        if pnl >= float(bot_cfg.get("daily_tp_usd", 999999)):
            msg = f"daily TP reached (${pnl:.2f}) — bot pause"
            logger.info(f"[{bot_id}] 🎉 {msg}")
            self.db.update_status(sid, "skipped", msg)
            return
        if pnl <= -float(bot_cfg.get("daily_sl_usd", 999999)):
            msg = f"daily SL hit (${pnl:.2f}) — bot pause"
            logger.info(f"[{bot_id}] ⛔ {msg}")
            self.db.update_status(sid, "skipped", msg)
            return

        # 2. Max open orders
        n_open = executor.count_open_orders()
        max_open = int(bot_cfg.get("max_open_orders", 1))
        if n_open >= max_open:
            msg = f"max open orders ({n_open}/{max_open})"
            logger.info(f"[{bot_id}] ⏸ {msg}")
            self.db.update_status(sid, "skipped", msg)
            return

        # 3. Tính SL/TP
        sl_price, tp_price, sl_tp_note = self._compute_sl_tp(sig, bot_cfg)
        if sl_price is None and bot_cfg.get("require_sl", True):
            msg = "require_sl=true nhưng không tính được SL"
            logger.warning(f"[{bot_id}] ⚠ {msg}")
            self.db.update_status(sid, "skipped", msg)
            return

        # 4. Gửi lệnh
        lot = float(bot_cfg.get("lot", 0.01))
        ticket = executor.send_order(
            direction=action,
            lot=lot,
            sl=sl_price,
            tp=tp_price,
            comment=f"{bot_id}#{sid}",
        )

        if ticket:
            self.db.update_status(
                sid,
                "done",
                f"OK | lot={lot} | {sl_tp_note} | pnl_day=${pnl:.2f}",
                mt5_ticket=ticket,
            )
        else:
            self.db.update_status(sid, "failed", "order_send returned None")

    # ─────────────────────────────────────────────────────────────────────
    def run(self):
        self.running = True
        logger.info("=" * 70)
        logger.info(f"⚙️  Worker started | symbol={self.symbol}")
        logger.info(f"   Bots in config: {list(self.bots_config.keys())}")
        logger.info(f"   Poll interval: {POLL_INTERVAL}s")
        logger.info("=" * 70)

        while self.running:
            try:
                pending = self.db.fetch_pending(limit=20)
                for sig in pending:
                    logger.info(
                        f"📨 Processing #{sig['id']} {sig['bot_id']} {sig['action']}"
                    )
                    self._process_signal(sig)
                time.sleep(POLL_INTERVAL)
            except KeyboardInterrupt:
                logger.info("⏹ Stopping worker (Ctrl+C)")
                self.running = False
                break
            except Exception as e:
                logger.error(f"❌ Worker loop error: {e}", exc_info=True)
                time.sleep(5)

        # Cleanup
        for bot_id, ex in self.executors.items():
            ex.disconnect()
        logger.info("✓ Worker stopped")


if __name__ == "__main__":
    w = Worker()
    w.run()
